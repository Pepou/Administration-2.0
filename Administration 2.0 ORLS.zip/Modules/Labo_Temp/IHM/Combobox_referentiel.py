# -*- coding: utf-8 -*-

"""
Module implementing Combobox_referentiel.
"""

from PyQt4.QtCore import pyqtSlot
from PyQt4.QtGui import QWidget
from PyQt4.QtCore import SIGNAL
from .Ui_Combobox_referentiel import Ui_Combobox_referentiel


class Combobox_referentiel(QWidget, Ui_Combobox_referentiel):
    """
    Class documentation goes here.
    """
    def __init__(self, referentiel , parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget (QWidget)
        """
        super(Combobox_referentiel, self).__init__(parent)
        self.setupUi(self)
        self.comboBox.addItems(referentiel)
        
    @pyqtSlot(str)
    def on_comboBox_activated(self, p0):
        """
        Slot documentation goes here.
        """
        
        id_ref = self.comboBox.currentIndex()
        self.emit(SIGNAL("fermetureCombobox_referentiel(PyQt_PyObject)"), id_ref)
        self.close()
