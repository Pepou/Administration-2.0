# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Travail\EFS\Travail accreditation\SQ\Developpement Informatique\LaboTemp\Builds\V1.23\IHM\Combobox_referentiel.ui'
#
# Created: Thu Dec 31 14:30:19 2015
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Combobox_referentiel(object):
    def setupUi(self, Combobox_referentiel):
        Combobox_referentiel.setObjectName(_fromUtf8("Combobox_referentiel"))
        Combobox_referentiel.resize(455, 80)
        self.verticalLayout = QtGui.QVBoxLayout(Combobox_referentiel)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label = QtGui.QLabel(Combobox_referentiel)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout.addWidget(self.label)
        self.comboBox = QtGui.QComboBox(Combobox_referentiel)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.verticalLayout.addWidget(self.comboBox)

        self.retranslateUi(Combobox_referentiel)
        QtCore.QMetaObject.connectSlotsByName(Combobox_referentiel)

    def retranslateUi(self, Combobox_referentiel):
        Combobox_referentiel.setWindowTitle(_translate("Combobox_referentiel", "Referentiels de Conformite", None))
        self.label.setText(_translate("Combobox_referentiel", "Merci de selectionner le referentiel de la campagne d\'etalonnage", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Combobox_referentiel = QtGui.QWidget()
    ui = Ui_Combobox_referentiel()
    ui.setupUi(Combobox_referentiel)
    Combobox_referentiel.show()
    sys.exit(app.exec_())

