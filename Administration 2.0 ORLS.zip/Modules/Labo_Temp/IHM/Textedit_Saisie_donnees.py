#from PyQt4.QtCore import  Qt
from PyQt4.QtGui import QTextEdit, QApplication


class Textedit_Saisie_donnees(QTextEdit):
    """gestion copier- coller :
    Pour cela il faut tjr reimplementer canInsertFromMimeData et insertFromMimeData"""
    
    def __init__(self, parent=None):

        super(Textedit_Saisie_donnees, self).__init__(parent)
        

    def canInsertFromMimeData(self, source):

        return super(Textedit_Saisie_donnees, self).canInsertFromMimeData(source)

    def insertFromMimeData(self, source):
        presse_papier =  QApplication.clipboard()
        read_press_papier = presse_papier.text().split()

        for ele in read_press_papier:
            try:
                value = ele.replace(",", ".")
                float(value)
                self.append(value)
        
        
            except ValueError:
                pass
        
        
        
        
        
